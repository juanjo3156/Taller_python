diccionario = {}
diccionario = dict()


diccionario = {
    'elemento_1':1,
    'elemento_2':True,
    'elemento_3':"Fernando",
    'elemento_4':[1,2,3]
    }

print(diccionario.keys())

print(diccionario.values())