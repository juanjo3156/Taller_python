edad = int(input("Inserta tu edad: "))
if edad>18:
    print("Eres mayor de edad")
elif edad <= 0:
    print("Edad no valida eres muy joven o no existes")
else:
    print("Eres menor de edad")