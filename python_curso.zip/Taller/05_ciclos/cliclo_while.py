
#El codigo se ejecutara hasta que 
#"i" deje de ser menor que 6
# i = 1
# while i <= 6:
#   print(i)
#   i += 1

# cocacola = True
# while cocacola:
#     print("Hola")
#     cocacola = False

#Sentencia break
#Con la sentencia break podemos detener
#el bucle incluso si la condición while
#es verdadera:

#El ciclo se acabara 
#cuando i sea igual a 3 sin respetar 
#la condición
# i = 1
# while i < 6:
#   print(i)
#   if i == 3:
#     break
#   i += 1

#Con la instrucción continue podemos 
#detener la iteración actual y 
#continuar con la siguiente:

#No se ejecutara la iteración 
#cuando i sea igual a 3 y 
#continuara con la siguiente
# i = 0
# while i < 6:
#   i += 1
#   if i == 3:
#     continue
#   print(i)

#Con la instrucción else podemos ejecutar 
#un bloque de código una vez que la condición
#ya no es verdadera:

#Imprime un mensaje una vez que la 
#condición sea falsa:
# i = 1
# while i < 6:
#   print(i)
#   i += 1
# else:
#   print("i ya no es menor que 6")