#imprime un hola mundo
print("Hola mundo")