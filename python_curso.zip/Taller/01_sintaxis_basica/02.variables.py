comida = "pizza"
print(comida)