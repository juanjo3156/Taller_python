#suma o adición
suma = 2 + 2
print(suma)

#resta o sustracción
resta = 4-1
print(resta)

#multiplicación 
multi = 2*2
print(multi)

#división
divi = 4/2
print(divi)

#modulo
modulo = 4%2
print(modulo)

#potencia
poten = 2**2
print(poten)

#división entera
divint = 4//2
print(divint)