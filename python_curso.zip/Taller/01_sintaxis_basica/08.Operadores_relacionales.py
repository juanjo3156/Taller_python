#Mayor que
mayor = 4>1
print(mayor)

#Menor que
menor = 1<3
print(menor)

#Igual que
igual = 2 == 2
print(igual)

#Mayor o igual
mayigual = 5>=4
print(mayigual)

#Menor o igual
menigual = 5 <= 3
print(menigual)

#Diferente de
dif = 5 != 5
print(dif)