ingresos = float(input("Ingresos: "))
edad = int(input("Edad: "))

if ingresos >= 1000 and edad > 16:
    print("puedes tributar")
else:
    print("No puedes tributar te salvaste jaja XD ")

