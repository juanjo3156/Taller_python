#mayor que
mayor = 56 > 10
print(mayor)

#menor que
menor = 100<90
print(menor)

#compación de iguales
igual = 4 == 4
print(igual)

#mayor o igual

mayi= 4>=5
print(mayi)

meni = 4<=5
print(meni)

#diferente de

difer = 4 != 4
print(difer)