numero1 = int(input("ingresa un numero:"))
numero2 = int(input("ingresa un segundo numero:"))
 
#suma
# suma = numero1+numero2
# print(suma)

# resta = numero1-numero2
# print(resta)

#multiplicación
# multi = numero1*numero2+10
# print(multi)

#division
# div = numero1/numero2
# print(div)

#division entera
# divint = numero1//numero2
# print(divint)

#modulo o resto
# modulo = numero1%numero2
# print(modulo)

#potenciación
potencia = numero1**numero2
print(potencia)