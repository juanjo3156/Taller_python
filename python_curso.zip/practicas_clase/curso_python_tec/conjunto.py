conjunto = {}
print(type(conjunto))

conjunto2 = set([1,2,3])
print(conjunto2)
