# esto es un comentario de línea

""" Esto es un comentario
de más de una linea,
todo lo que ponga será ignorado
por el interprete de Python """

print("Hola mundo") # Imprime un hola mundo