animal = 'ardilla'
print(animal)

# Se puede indicar el tipo de dato de una variable
numero: int = 10
print(type(numero))
# Pero esto no es estricto en su contenido
# numero: int = "10"
print(type(numero))