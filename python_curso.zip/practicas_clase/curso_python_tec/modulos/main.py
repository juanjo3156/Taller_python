from matematicas import suma


def main():
    resultado = suma(1, 2)
    print(resultado)


if __name__ == '__main__':
    main()