numero = input("ingresa un numero: ")
suma = int(numero) + 2
print(suma)

# Cambiando el tipo de dato de un input
num = int(input("Ingresa un numero: "))

# Diferentes formas de definir una variable
variable_num = int()
print(variable_num)
booleano = bool()
print(booleano)
flotante = float()
print(flotante)
cadena = str()
print(cadena)
complejo = complex()
print(complejo)
nada = None
print(nada)