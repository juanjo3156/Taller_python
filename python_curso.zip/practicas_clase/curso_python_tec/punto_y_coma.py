# En Python se puede usar ';' para separar instrucciones en un misma linea
print("Hola"); print("Adios"); var = 10; print(var)