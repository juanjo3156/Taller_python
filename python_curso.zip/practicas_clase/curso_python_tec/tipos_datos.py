entero = 156
#type()
print(type(entero))
flotante  = 1.6
print(type(flotante))
complejo = 1 + 3j
print(type(complejo))
complejo1 = complex(1,3)
print(type(complejo1))
cadena = "hola mundo"
print(type(cadena))
booleano = True
print(type(booleano))
nada = None
print(type(nada))